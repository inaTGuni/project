package servlet;

public class GitPractice {
	public static void main(String[] args) {
		System.out.println("Hello, Tanaka");
	}
}
